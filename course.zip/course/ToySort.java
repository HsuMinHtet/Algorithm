import java.util.Arrays;

public class ToySort {
	
	public static void swap(int[] A, int i, int j) {
		int temp = A[i];
		A[i] = A[j];
		A[j] = temp;
	}

	public static void toySort(int[] A, int lower, int upper, int startColor, int endColor) {
		
		if (startColor == endColor || lower == upper) return;
		int lastLeftColor = (startColor + endColor)/2;
				
		int lowerPtr = lower;
		int upperPtr = upper;
		
		while (true) {
			while (lowerPtr <= upperPtr && A[lowerPtr] <= lastLeftColor) lowerPtr++;
	        while (lowerPtr <= upperPtr && A[upperPtr] > lastLeftColor) upperPtr--;
			if (lowerPtr  <= upperPtr)
				swap(A, lowerPtr++, upperPtr);
			else
				break;
			}	

		toySort(A, lower, lowerPtr-1, startColor, lastLeftColor);
		toySort(A, lowerPtr, upper, lastLeftColor + 1, endColor);	
	}
	
	public static void main(String[] args) {
		int toyBlocks[] = new int[] {7, 6, 4, 3, 4, 1, 3, 7, 2, 5, 4, 3, 7, 1, 4, 2, 5};
		System.out.println(String.format("Before sorting : %s", Arrays.toString(toyBlocks)));
        toySort(toyBlocks,0, toyBlocks.length - 1, 1, 7);
        System.out.println(String.format("Sorted array : %s", Arrays.toString(toyBlocks)));
	}
}

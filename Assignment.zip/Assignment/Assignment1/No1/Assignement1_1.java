package Assignment1.No1;

import java.util.Random;

public class Assignement1_1 {

    public static int algorithm1(int[] arr) {
        int[] evenNumbers = new int[arr.length]; // Assuming all elements are even initially
        int count = 0;
        for (int num : arr) {
            if (num % 2 == 0) {
                evenNumbers[count++] = num;
            }
        }
        int maxDistance = Integer.MIN_VALUE;
        for (int i = 0; i < count; i++) {
            for (int j = i + 1; j < count; j++) {
                int distance = Math.abs(evenNumbers[i] - evenNumbers[j]);
                if (distance > maxDistance) {
                    maxDistance = distance;
                }
            }
        }
        return maxDistance;
    }

    public static int algorithm2(int[] arr) {
        int maxDistance = Integer.MIN_VALUE;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] % 2 == 0) {
                for (int j = i + 1; j < arr.length; j++) {
                    if (arr[j] % 2 == 0) {
                        int distance = Math.abs(arr[i] - arr[j]);
                        if (distance > maxDistance) {
                            maxDistance = distance;
                        }
                    }
                }
            }
        }
        return maxDistance;
    }

    public static int algorithm3(int[] arr) {
        int max = Integer.MIN_VALUE;
        int min = Integer.MAX_VALUE;
        for (int num : arr) {
            if (num % 2 == 0) {
                if (max < num) {
                    max = num;
                }
                if (min > num) {
                    min = num;
                }
            }
        }
        return max - min;
    }

    public static void main(String[] args) {
        // Testing the algorithms with different problem sizes
        int[] problemSizes = {1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000};
        System.out.println("Problem Size\tAlgorithm 1\tAlgorithm 2\tAlgorithm 3");
        for (int size : problemSizes) {
            int[] arr = generateRandomArray(size);
            long start, end;

            start = System.nanoTime();
            algorithm1(arr);
            end = System.nanoTime();
            long algorithm1Time = end - start;

            start = System.nanoTime();
            algorithm2(arr);
            end = System.nanoTime();
            long algorithm2Time = end - start;

            start = System.nanoTime();
            algorithm3(arr);
            end = System.nanoTime();
            long algorithm3Time = end - start;

            System.out.printf("%d\t\t%d\t\t%d\t\t%d\n", size, algorithm1Time, algorithm2Time, algorithm3Time);
        }
    }

    private static int[] generateRandomArray(int size) {
        int[] arr = new int[size];
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            arr[i] = random.nextInt(size);
        }
        return arr;
    }
}

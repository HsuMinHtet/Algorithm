public class BuildHeap_ButtonUp {
    private static int comparisons;

    public static void buildMaxHeapBottomUp(int[] A) {
        int n = A.length;
        comparisons = 0;
        for (int i = n / 2; i >= 1; i--) {
            System.out.println("Iteration=> " + i + ": " + java.util.Arrays.toString(downHeap(A, i, n)));
            System.out.println("Comparison : " + comparisons);
        }
    }

    private static int[] downHeap(int[] A, int i, int n) {
        int j = i;
        int k = maxChildIndex(A, j, n);
        while (k != 0) {
            if (A[j - 1] < A[k - 1]) {
                int temp = A[j - 1];
                A[j - 1] = A[k - 1];
                A[k - 1] = temp;
                comparisons++; // Increment comparison count on swap
            }
            j = k;
            k = maxChildIndex(A, j, n);
        }
        return A;
    }

    private static int maxChildIndex(int[] A, int i, int n) {
        int leftChild = 2 * i;
        int rightChild = 2 * i + 1;
        if (rightChild <= n) {
            comparisons++; // Increment comparison count for checking right child
            return (A[leftChild - 1] > A[rightChild - 1]) ? leftChild : rightChild;
        } else if (leftChild <= n) {
            return leftChild;
        } else {
            return 0;
        }
    }

    public static void main(String[] args) {
        int[] A = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
        int[] B = {2, 1, 4, 3, 6, 5, 8, 7, 10, 9, 12, 11, 14, 13, 16, 15};
        int[] C = {4, 2, 3, 1, 5, 8, 7, 6, 11, 10, 12, 9, 13, 14, 16, 15};
        int[] D = {5, 6, 7, 4, 2, 3, 1, 8, 11, 13, 14, 16, 10, 12, 11, 9};

        buildMaxHeapBottomUp(C);
        System.out.println("Number of comparisons during heap construction: " + comparisons);
    }
}



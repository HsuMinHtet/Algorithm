public class HaultTesting {

    public static int test(int n){
        if(n==1){ //n<=1 hault
            return n;
        }
        if(n%2==0){
            return test(n/2);
        }
        else{
            return test((3*n+1)/2);
        }

    }

    public static void main(String[] args) {
        System.out.println("Test n=100 => "+test(-1));
    }
}

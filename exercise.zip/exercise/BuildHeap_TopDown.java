public class BuildHeap_TopDown {
    private static int comparisons;

    public static void buildMaxHeapTopDown(int[] A) {
        int n = A.length;
        comparisons = 0;
        for (int i = 1; i <= n; i++) {
            System.out.println("Iteration=> " + i + ": " + java.util.Arrays.toString(upHeap(A, i)));
            System.out.println("Comparison : " + comparisons);
        }
    }

    private static int[] upHeap(int[] A, int i) {
        int j = i;
        while (j > 1) {
            comparisons++; // Increment comparison count on swap
            if (A[j - 1] > A[j / 2 - 1]) {
                int temp = A[j - 1];
                A[j - 1] = A[j / 2 - 1];
                A[j / 2 - 1] = temp;
                j = j / 2;
            } else {
                break;
            }
        }
        return A;
    }

    public static void main(String[] args) {
        int[] A = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
        int[] B = {2, 1, 4, 3, 6, 5, 8, 7, 10, 9, 12, 11, 14, 13, 16, 15};
        int[] C = {4, 2, 3, 1, 5, 8, 7, 6, 11, 10, 12, 9, 13, 14, 16, 15};
        int[] D = {5, 6, 7, 4, 2, 3, 1, 8, 11, 13, 14, 16, 10, 12, 11, 9};

        buildMaxHeapTopDown(D);
        System.out.println("Number of comparisons during heap construction: " + comparisons);
    }
}

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class DFS {
    private List<List<Integer>> graph; // Graph representation( 2 dimensional)
    private boolean[] visited; // Visited vertices tracker

    //Constructor
    public DFS(int vertices) {
        graph = new ArrayList<>(vertices);
        visited = new boolean[vertices];
        for (int i = 0; i < vertices; i++) {
            graph.add(new ArrayList<>()); // Initialize adjacency lists
        }
    }

    // Adds an edge to the undirected graph
    public void addEdge(int src, int dest) {
        graph.get(src).add(dest);
        graph.get(dest).add(src); // Since the graph is undirected
    }

    // DFS algorithm implementation
    public void dfs(int start) {
        Stack<Integer> stack = new Stack<>();

        // Mark the starting vertex as visited and push it onto the stack
        visited[start] = true;
        stack.push(start);

        while (!stack.isEmpty()) {
            int v = stack.peek();
            System.out.println("Peek form Stack:"+ v);
            boolean foundUnvisited = false;

            // Explore the adjacency list of vertex v
            for (int w : graph.get(v)) {
                if (!visited[w]) {
                    // Mark the next unvisited vertex and push it onto the stack
                    visited[w] = true;
                    stack.push(w);
                    foundUnvisited = true;
                    break; // Exit the for loop once an unvisited vertex is found
                }
            }

            // If no unvisited adjacent vertex is found, backtrack
            if (!foundUnvisited) {
                stack.pop();
            }
        }
    }

    public static void main(String[] args) {
        // Example usage
        int numVertices = 6; // Example number of vertices
        DFS dfs = new DFS(numVertices);

//        // Adding edges
//        dfs.addEdge(0, 1);
//        dfs.addEdge(0, 2);
//        dfs.addEdge(0, 5);
//
//        dfs.addEdge(1, 5);
//
//        dfs.addEdge(2, 5);
//        dfs.addEdge(2, 6);
//
//        dfs.addEdge(3, 4);
//        dfs.addEdge(3, 8);
//
//        dfs.addEdge(4, 8);
//
//        dfs.addEdge(5, 7);
//
//        dfs.addEdge(6, 7);

        dfs.addEdge(0, 1);
        dfs.addEdge(0, 5);
        dfs.addEdge(1, 2);
        dfs.addEdge(1, 5);
        dfs.addEdge(2, 3);
        dfs.addEdge(2, 4);
        dfs.addEdge(2, 5);
        dfs.addEdge(3, 4);
        dfs.addEdge(4, 5);

        // Perform DFS from vertex 0
        dfs.dfs(5);

        // This example doesn't explicitly output the visitation,
        // but you can modify the dfs method to print vertices as they're visited.
    }


}

import java.util.Random;

public class FindMax {
    public static int algorithm1(int[] A) {
        int firstMax = 0, secondMax = 0, thirdMax = 0;
        int firstIndex = -1, secondIndex = -1;
        for (int i = 0; i < A.length; i++) {
            if (firstMax < A[i]) {
                firstMax = A[i];
                firstIndex = i;
            }
        }
        for (int i = 0; i < A.length; i++) {
            if (firstMax != 0 && firstIndex != i && secondMax < A[i]) {
                secondMax = A[i];
                secondIndex = i;
            }
        }
        for (int i = 0; i < A.length; i++) {
            if (firstMax != 0 && secondMax != 0) {
                if (firstIndex != i && secondIndex != i) {
                    if (thirdMax < A[i]) {
                        thirdMax = A[i];
                    }
                }
            }
        }
        return thirdMax;
    }

    public static int algorithm2(int[] A) {
        int max = 0, preMax = 0, prePreMax = 0;
        int maxIndex = -1, preMaxIndex = -1;
        int i = 0, j = 0, x = 0;
        while (x < A.length) {
            if (i < A.length) {
                if (max < A[i]) {
                    max = A[i];
                    maxIndex = i;
                }
                i++;
            } else if (j < A.length) {
                if (maxIndex != j && preMax < A[j]) {
                    preMax = A[j];
                    preMaxIndex = j;
                }
                j++;
            } else if (x < A.length) {
                if (maxIndex != x && preMaxIndex != x && prePreMax < A[x]) {
                    prePreMax = A[x];
                }
                x++;
            }
        }
        return prePreMax;
    }

    public static void main(String[] args) {
        //int[] test ={7,20,18,4,20,19,20,3};
        int[] problemSizes = {1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000};
        System.out.println("Size: Algorithm1 Algorithm2 ");
        for (int size : problemSizes) {
            int[] arr = generatedRandomArray(size);
            long start, end;

            start = System.nanoTime();
            algorithm1(arr);
            end = System.nanoTime();
            long duration1 = end - start;

            start = System.nanoTime();
            algorithm2(arr);
            end = System.nanoTime();
            long duration2 = end - start;

            System.out.printf("%d\t\t%d\t\t%d\n", size, duration1, duration2);
        }
    }

    private static int[] generatedRandomArray(int size) {
        int[] arr = new int[size];
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            arr[i] = random.nextInt(size);
        }
        return arr;
    }
}
